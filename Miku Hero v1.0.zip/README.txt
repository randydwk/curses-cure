## Controls

Use the mouse to navigate in the menus.

Once in a level, the commands are C V B N.

## Details

At the beginning, this was a test project about Hatsune Miku I made in 2017 on GMS1.4.

Then I wanted to continue it on GMS2 because I liked the idea.

Finally, I finished it in July 2019, with 22 playable musics in total, after at least 6 months of work.